package TDE2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import java.text.DecimalFormat;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Set;

public class PerformanceAnalysisDriver extends Configured implements Tool {

    public static void main(String []args) throws Exception{
        BasicConfigurator.configure();
        int result = ToolRunner.run(new Configuration(), new PerformanceAnalysisDriver(), args);
        System.exit(result);
    }
    @Override
    public int run(String[] args) throws Exception {
        Configuration conf = new Configuration();

        Path input = new Path(args[0]);
        Path intermediate = new Path(args[1]);
        Path output = new Path(args[2]);

        Job firstJob = Job.getInstance(conf);
        firstJob.setJobName("PerformanceAVG");

        FileInputFormat.addInputPath(firstJob, input);
        FileSystem.get(conf).delete(intermediate, true);
        FileOutputFormat.setOutputPath(firstJob, intermediate);

        firstJob.setJarByClass(PerformanceAnalysisDriver.class);
        firstJob.setMapperClass(PerformanceMapper.class);
        firstJob.setReducerClass(PerformanceReducer.class);

        firstJob.setMapOutputKeyClass(Text.class);
        firstJob.setMapOutputValueClass(AvgPerformanceWritable.class);
        firstJob.setOutputKeyClass(Text.class);
        firstJob.setOutputValueClass(FloatWritable.class);

        int firstJobResult = firstJob.waitForCompletion(true)? 0: 1;
        if(firstJobResult == 0){
            Job secondJob = Job.getInstance(conf);
            secondJob.setJobName("CompareAverage");

            //2 inputs, 1 is the .csv and the other is the intermediate
            FileInputFormat.addInputPath(secondJob, intermediate);
            FileInputFormat.addInputPath(secondJob, input);
            FileSystem.get(conf).delete(output, true);
            FileOutputFormat.setOutputPath(secondJob, output);

            secondJob.setJarByClass(PerformanceAnalysisDriver.class);
            secondJob.setMapperClass(AvgComparisonMapper.class);
            secondJob.setReducerClass(AvgComparisonReducer.class);

            secondJob.setMapOutputKeyClass(Text.class);
            secondJob.setMapOutputValueClass(PerformanceWritable.class);
            secondJob.setOutputKeyClass(Text.class);
            secondJob.setOutputValueClass(Text.class);
            return secondJob.waitForCompletion(true) ? 0 : 1;
        }
        return 1;
    }

    public static class PerformanceMapper extends Mapper<LongWritable, Text, Text, AvgPerformanceWritable> {
        public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {
            String line = value.toString();
            String[] columns = line.split(",");
            if(columns.length > 0 && !columns[0].equals("Employee_ID")){
                if(!columns[0].isEmpty() && !columns[8].isEmpty()){
                    float performanceScore = Float.parseFloat(columns[8]);
                    con.write(new Text("average,"), new AvgPerformanceWritable(performanceScore, 1));
                }
            }
        }
    }
    public static class PerformanceReducer extends Reducer<Text, AvgPerformanceWritable, Text, FloatWritable>{
        public void reduce(Text key, Iterable<AvgPerformanceWritable> value, Context con) throws IOException, InterruptedException{
            int sumN = 0;
            float sumScore = 0f;
            for(AvgPerformanceWritable v: value){
                float currScore = v.getPerformanceScore();

                String textKey = key.toString();
                sumN += v.getCount();
                sumScore += currScore;
            }
            float avgScore = sumScore/sumN;
            con.write(key, new FloatWritable(avgScore));
        }
    }
    public static class AvgComparisonMapper extends Mapper<LongWritable, Text, Text, PerformanceWritable> {
        public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException{
            String line = value.toString();
            String []columns = line.split(",");
            if(columns.length > 0 && !columns[0].equals("Employee_ID")){
                if(columns.length == 2){
                    if(columns[0].equals("average")){
                        String employeeID = columns[0];
                        float performanceScore = Float.parseFloat(columns[1]);
                        con.write(new Text("average"), new PerformanceWritable(employeeID, performanceScore));
                    }
                }
                else if(!columns[0].isEmpty() && !columns[8].isEmpty()){
                    String employeeID = columns[0];
                    float performanceScore = Float.parseFloat(columns[8]);
                    con.write(new Text("average"), new PerformanceWritable(employeeID, performanceScore));
                }
            }
        }
    }

    public static class AvgComparisonReducer extends Reducer<Text, PerformanceWritable, Text, Text>{
        public void reduce(Text key, Iterable<PerformanceWritable> values, Context con) throws IOException, InterruptedException {
            float average = 0f;
            HashMap<String, Float> data = new HashMap<>();
            for(PerformanceWritable v: values) data.put(v.getId(), v.getScore());

            average = data.get("average");
            Set<String> keys = data.keySet();

            for(String k : keys){
                if(!k.equals("average")){
                    if(data.get(k) < average){
                        con.write(new Text(k), new Text("Produtividade: "+(average -data.get(k))+" pontos abaixo da média"));
                    }
                    else if (data.get(k) > average){
                        con.write(new Text(k), new Text("Produtividade: "+(data.get(k)-average)+" pontos acima da média"));
                    }
                    else{
                        con.write(new Text(k), new Text("Produtividade na média"));
                    }
                }
            }

        }
    }
}
