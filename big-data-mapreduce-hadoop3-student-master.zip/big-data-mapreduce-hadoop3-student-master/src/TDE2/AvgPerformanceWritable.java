package TDE2;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class AvgPerformanceWritable implements Writable {
    private float performanceScore;
    private int count;
    public AvgPerformanceWritable(){}

    public AvgPerformanceWritable(float performanceScore, int count) {
        this.performanceScore = performanceScore;
        this.count = count;

    }

    public float getPerformanceScore() {return this.performanceScore;}

    public void setPerformanceScore(int performanceScore) {this.performanceScore = performanceScore;}

    public int getCount() {return this.count;}

    public void setCount(int count) {this.count = count;}
    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(this.performanceScore);
        dataOutput.writeInt(this.count);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.performanceScore = dataInput.readFloat();
        this.count = dataInput.readInt();
    }
}
