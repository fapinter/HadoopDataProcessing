package Entropy;

import org.apache.commons.collections.IterableMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;
import java.util.HashMap;
import java.util.Set;

public class EntropyDriver extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        //Configuração
        BasicConfigurator.configure();
        //Chamada do driver com a passagem dos parametros
        int result = ToolRunner.run(new Configuration(), new EntropyDriver(), args);
        System.exit(result);
    }

    @Override
    public int run(String[] args) throws Exception{
        Configuration conf = new Configuration();

        //Path dos arquivos
        Path input = new Path(args[0]);
        Path intermediate = new Path(args[1]);
        Path output = new Path(args[2]);

        //Quantidade de Reducers, caso n passe argumento tem 2 reducers por padrão
        int reducers = (args.length > 3) ? Integer.parseInt(args[3]) : 2;

        //configuração job1
        Job job1 = Job.getInstance(conf);
        job1.setJobName("CountCharacters");
        job1.setNumReduceTasks(reducers);

        FileInputFormat.addInputPath(job1, input);
        FileSystem.get(conf).delete(intermediate, true);
        FileOutputFormat.setOutputPath(job1, intermediate);
        job1.setJarByClass(EntropyDriver.class);
        job1.setMapperClass(CharacterCountMapper.class);
        job1.setReducerClass(CharacterCountReducer.class);

        //Define output keys and values data types for Mapper and Reducer
        job1.setMapOutputKeyClass(Text.class);
        job1.setOutputValueClass(IntWritable.class);

        job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(IntWritable.class);

        if(job1.waitForCompletion(true)){
            Job job2 = Job.getInstance(conf);
            job2.setJobName("Entropy");
            job2.setNumReduceTasks(reducers);

            FileInputFormat.addInputPath(job2, intermediate);
            FileSystem.get(conf).delete(output, true);
            FileOutputFormat.setOutputPath(job2, output);

            job2.setJarByClass(EntropyDriver.class);
            job2.setMapperClass(EntropyMapper.class);
            job2.setReducerClass(EntropyReducer.class);

            job2.setMapOutputKeyClass(Text.class);
            job2.setMapOutputValueClass(EntropyWritable.class);
            job2.setOutputKeyClass(Text.class);
            job2.setOutputValueClass(DoubleWritable.class);

            return job2.waitForCompletion(true)? 0 : 1;
        }

        return 1;
    }

    public static class CharacterCountMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
        public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {
            String line = value.toString();
            //Não pega a primeira linha com o nome da proteina
            if(!line.startsWith(">")){
                String[] chars = line.split("");
                for(String ch: chars){
                    con.write(new Text(ch), new IntWritable(1));
                    con.write(new Text("Total"), new IntWritable(1));
                }
            }
        }
    }

    public static class CharacterCountReducer extends Reducer<Text, IntWritable, Text, IntWritable>{
        public void reduce(Text key, Iterable<IntWritable> values, Context con) throws IOException, InterruptedException{
            int count = 0;
            for(IntWritable v: values){
                count += v.get();
            }
            con.write(key, new IntWritable(count));
        }
    }
    public static class EntropyMapper extends Mapper<LongWritable, Text, Text, EntropyWritable>{
        public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {
            String line = value.toString();
            String[] data = line.split("\t");
            String characters = data[0];
            int count = Integer.parseInt(data[1]);
            con.write(new Text("entropy"), new EntropyWritable(characters, count));
        }
    }

    public static class EntropyReducer extends Reducer<Text, EntropyWritable, Text, DoubleWritable>{
        public void reduce(Text key, Iterable<EntropyWritable> values, Context con) throws IOException, InterruptedException{

            int total = 0;
            //HashMap needed to guarantee that the division um the p math doesn't
            //result in -infinity (total = 0)
            HashMap<String, Integer> data = new HashMap<String, Integer>();
            for(EntropyWritable v: values) data.put(v.getCharacters(), v.getCount());

            total = data.get("Total");
            Set<String> keys = data.keySet();

            for(String k: keys){
                if(!k.equals("Total")){
                    float p = (float) data.get(k) / total;
                    double entropy = -p * Math.log(p);
                    con.write(new Text(k), new DoubleWritable(entropy));
                }
            }
        }
    }
}
