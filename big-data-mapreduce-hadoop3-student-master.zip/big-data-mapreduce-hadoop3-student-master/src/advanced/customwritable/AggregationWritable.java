package advanced.customwritable;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class AggregationWritable  implements Writable{
    private float max;
    private float min;
    private float avg;
    private int N;

    public AggregationWritable(){}

    public AggregationWritable(float max, float min, float avg, int n) {
        this.max = max;
        this.min = min;
        this.avg = avg;
        this.N = n;
    }

    public float getMax() {
        return max;
    }

    public void setMax(float max) {
        this.max = max;
    }

    public float getMin() {
        return min;
    }

    public void setMin(float min) {
        this.min = min;
    }

    public float getAvg() {
        return avg;
    }

    public void setAvg(float avg) {
        this.avg = avg;
    }

    public int getN() {
        return N;
    }

    public void setN(int n) {
        N = n;
    }

    @Override
    public String toString(){
        return "";
    }
    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(this.max);
        dataOutput.writeFloat(this.min);
        dataOutput.writeFloat(this.avg);
        dataOutput.writeInt(this.N);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {

    }
}
