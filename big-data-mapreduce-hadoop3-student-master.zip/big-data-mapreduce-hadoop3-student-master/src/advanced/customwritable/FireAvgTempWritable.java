package advanced.customwritable;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.checkerframework.checker.units.qual.Temperature;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class FireAvgTempWritable implements Writable{
    private float sumTemp;
    private int sumN;

    public FireAvgTempWritable(){}
    public FireAvgTempWritable(float sumTemp, int sumN){
        this.sumTemp = sumTemp;
        this.sumN = sumN;
    }

    public float getSumTemp() {
        return sumTemp;
    }

    public int getSumN() {
        return sumN;
    }

    public void setSumN(int sumN) {
        this.sumN = sumN;
    }

    public void setSumTemp(float sumTemp) {
        this.sumTemp = sumTemp;
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(sumTemp);
        dataOutput.writeInt(sumN);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.sumTemp = dataInput.readFloat();
        this.sumN = dataInput.readInt();
    }

    @Override
    public String toString() {
        return "FireAvgTempWritable{" +
                "sumTemp=" + sumTemp +
                ", sumN=" + sumN +
                '}';
    }
}
