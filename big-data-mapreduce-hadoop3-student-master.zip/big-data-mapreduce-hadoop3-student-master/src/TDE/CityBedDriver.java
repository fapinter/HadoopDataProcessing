package TDE;

import advanced.customwritable.WindTempDriver;
import advanced.customwritable.WindTempWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;


public class CityBedDriver extends Configured implements Tool {
    @Override
    public int run(String[] args) throws Exception {
        Configuration conf = new Configuration();
        //Using arguments
        Path input = new Path(args[0]);
        Path output = new Path(args[1]);
        int reducersQuantity = Integer.parseInt(args[2]);

        //Creating the job
        Job job = Job.getInstance(conf);
        job.setJobName("CityBed");
        job.setNumReduceTasks(reducersQuantity);

        //Config job Input and Output data
        FileInputFormat.addInputPath(job, input);
        FileSystem.get(conf).delete(output, true);
        FileOutputFormat.setOutputPath(job, output);

        //Config classes for Driver, Mapper, Combiner and Reducer
        job.setJarByClass(CityBedDriver.class);
        //Mapper
        job.setMapperClass(CityBedMapper.class);
        //Reducer
        job.setReducerClass(CityBedReducer.class);
        //Combiner
        job.setCombinerClass(CityBedCombiner.class);

        //Setting Inputs and Outputs
        job.setMapOutputKeyClass(CityBedWritable.class);
        job.setMapOutputValueClass(AvgPriceWritable.class);
        job.setOutputKeyClass(CityBedWritable.class);
        job.setOutputValueClass(FloatWritable.class);
        //Return of the Driver
        return job.waitForCompletion(true)? 0 : 1;
    }

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();

        int result = ToolRunner.run(new Configuration(),
                new CityBedDriver(), args);

        System.exit(result);
    }

    public static class CityBedMapper extends Mapper<LongWritable, Text, CityBedWritable, AvgPriceWritable> {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            String[] columns = line.split(",");
            if(columns.length > 0 && !columns[0].equals("brokered_by")){
                if(!columns[7].isEmpty() && !columns[3].isEmpty() && !columns[2].isEmpty()) {
                    String city = columns[7].replaceAll("^[A-Za-z].-", "");
                    if(!city.isEmpty()){
                        int bed = Integer.parseInt(columns[3]);
                        float price = Float.parseFloat(columns[2]);
                        context.write(new CityBedWritable(city, bed), new AvgPriceWritable(price, 1));
                    }
                }
            }
        }
    }

    public static class CityBedCombiner extends Reducer<CityBedWritable, AvgPriceWritable, CityBedWritable, AvgPriceWritable> {
        public void reduce(CityBedWritable key, Iterable<AvgPriceWritable> values, Context context) throws IOException, InterruptedException {
            float sumPrice = 0.0f;
            int count = 0;

            for(AvgPriceWritable val : values){
                sumPrice += val.getPrice();
                count += val.getN();
            }
            context.write(key, new AvgPriceWritable(sumPrice, count));
        }
    }

    public static class CityBedReducer extends Reducer<CityBedWritable, AvgPriceWritable, CityBedWritable, FloatWritable>{
        public void reduce(CityBedWritable key, Iterable<AvgPriceWritable> values, Context context) throws IOException, InterruptedException {
            float sumPrice = 0.0f;
            int count = 0;

            for(AvgPriceWritable val : values){
                sumPrice += val.getPrice();
                count += val.getN();
            }
            context.write(key, new FloatWritable(sumPrice/count));
        }
    }
}
