package TDE;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class CityBedWritable implements WritableComparable<CityBedWritable> {
    private String city;
    private int bed;

    public CityBedWritable(){

    }
    public CityBedWritable(String city, int bed) {
        this.city = city;
        this.bed = bed;
    }
    public static int compare(int x, int y){
        return (x < y)? -1 : ((x == y)? 0 : 1);
    }

    @Override
    public int compareTo(CityBedWritable o) {
        int v = this.city.compareTo(o.city);
        if(v != 0){
            return v;
        }
        return compare(this.bed, o.bed);
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(this.city);
        dataOutput.writeInt(this.bed);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.city = dataInput.readUTF();
        this.bed = dataInput.readInt();
    }
    @Override
    public boolean equals(Object object){
        if(this == object){
            return true;
        }
        if(object == null || getClass() != object.getClass()){
            return false;
        }
        CityBedWritable key = (CityBedWritable) object;
        return this.city.equals(key.city) && key.bed == this.bed;
    }

    @Override
    public int hashCode(){
        return this.city.hashCode()*163 + this.bed*10;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getBed() {
        return bed;
    }

    public void setBed(int bed) {
        this.bed = bed;
    }
}
