package TDE;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class AvgPriceWritable implements Writable {
    private float price;
    private int N;
    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(this.price);
        dataOutput.writeInt(this.N);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.price = dataInput.readFloat();
        this.N = dataInput.readInt();
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getN() {
        return N;
    }

    public void setN(int n) {
        N = n;
    }

    public AvgPriceWritable(){

    }
    public AvgPriceWritable(float price, int n) {
        this.price = price;
        N = n;
    }
}
